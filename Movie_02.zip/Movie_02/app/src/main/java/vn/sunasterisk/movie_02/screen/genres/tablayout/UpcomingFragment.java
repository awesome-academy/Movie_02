package vn.sunasterisk.movie_02.screen.genres.tablayout;

import android.view.View;

import vn.sunasterisk.movie_02.R;
import vn.sunasterisk.movie_02.base.BaseFragment;

public class UpcomingFragment extends BaseFragment {
    @Override
    protected void registerListener() {

    }

    @Override
    protected void initCoponents(View view) {

    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_upcoming;
    }
}
