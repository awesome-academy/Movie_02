package vn.sunasterisk.movie_02.screen.home;

public interface HomeContract {
}
