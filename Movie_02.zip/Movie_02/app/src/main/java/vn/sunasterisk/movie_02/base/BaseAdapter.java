package vn.sunasterisk.movie_02.base;

public class BaseAdapter {
}
