package vn.sunasterisk.movie_02.data.model;

public class NowPlaying {
}
